<section id="las-oleadas" class="about2">
   <div class="container">

      <div class="section-title">
         <h2>Nosotras</h2>
      </div>

      <div class="row">
         <div class="col-lg-6 order-1 order-lg-2">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
         </div>
         <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <h3>Somos <strong>Sole y Naty</strong>.</h3>
            <p>Creemos en el potencial de las personas para transformar su entorno y nos
               inspira acompañarlos durante todo el camino de la transformación con la finalidad de lograr un
               mundo mejor.</p>
            <p>Confiamos en los cambios de estilos de vida que promuevan el desarrollo sustentable
               buscando un equilibrio entre las personas, las organizaciones y el ambiente.</p>
         </div>
      </div>

   </div>
</section>