<?php
class Controller
{
    /*
    public function index()
    {
        echo 'Probando el Controller...';
    }
    */
}
